

function notiv (){
    $.bootstrapGrowl("You Have Sent",{
        type: "success",
        offset: {from: "top", amount: 250},
        align: "center",
        delay: 25000,
        allow_dismiss: true,
        stackup_spacing: 10,

    })
}